const navbarNav = document.querySelector('.navbarNav');
function openNavbar(){
    navbarNav.classList.add('open');
}
const close = document.querySelector('.navbarNav');
function shut(){
    navbarNav.classList.remove('open');
}


    